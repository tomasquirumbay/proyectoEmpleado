package modelo.mundo;

import java.util.InputMismatchException;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Empleado empleado1 = new Empleado();
		
		// TODO Auto-generated method stub
		
		//Declarar variables para los datos del empleado
		String nombreEmple;
		String apellidoEmple;
		int genero; //1 Femenino || 2 Masculino
		String imagen;
		double salario;
		Fecha fechaNac;
		Fecha fechaIngreso;
		int dia = 0;
		int mes = 0;
		int anio = 0;
		
		Scanner sn = new Scanner(System.in);
		int opcion=0; 
		
		//OPCIONES SISTEMA
		
		//1. Ingresa los datos del empleado.
		//2. Calcula  la edad del empleado.
		//3. Calcula la antiguedad del empleado.
		//4. Calcula las prestacines del empleado.
		//5. Visualiza la informaci�n del empleado.
		
		
		
		System.out.println("****MENU PRINCIPAL****");
		System.out.println("Escoja una de las siguientes opciones");
		System.out.println("1. Ingrese datos del empleado.");
		System.out.println("2. Calcular la edad del empleado");
		System.out.println("3. Calcular la antig�edad del empleado en la empresa");
		System.out.println("4. Calcular las prestaciones del empleado.");
		System.out.println("5. Visualizar la informaci�n del empleado");
		System.out.println("6. Salir");
		System.out.println("\nEscoja una de las opciones");
		opcion = sn.nextInt();
		switch(opcion) {
	
			
			case 1:
				System.out.println("Ingrese los datos del Empleado");
				System.out.println("Su nombre es: ");
				nombreEmple= sn.next();
				System.out.println("Su apellido es: ");
				apellidoEmple=sn.next();
				//genero=0;
				do {
					try {
				System.out.println("G�nero (1=Masculino, 2=Femenino)");
				genero=sn.nextInt();
				if(genero!=1 && genero!=2) {
					System.out.println(" Ingrese numeros correctos porfavor");	
				}
					}
					catch(InputMismatchException e1) {
						System.out.println("Debe ingresar solo numeros");
						genero=0;
						sn.nextLine();
					}
				}while(genero<1 || genero>2);
				do {
					try {
						System.out.println("Salario: ");
						salario=sn.nextDouble();
				     if(salario<=0) {
					System.out.println(" Ingrese un salario mayor a 0");	
				}
					}
					catch(InputMismatchException e1) {
						System.out.println("Debe ingresar solo numeros");
						salario=0;
						sn.nextLine();
					}
				}while(salario<=0);
				do {
					try {
						System.out.println("Ingrese su dia de nacimiento: ");
						dia=sn.nextInt();
				     if(dia<=0 || dia>31 ) {
					System.out.println(" Ingrese un dia correcto");	
				}
					}
					catch(InputMismatchException e1) {
						System.out.println("Ingrese solo numeros");
						dia=0;
						sn.nextLine();
					}
				}while(dia<=0 || dia>31);
				do {
					try {
						System.out.println("Ingrese su mes de Nacimiento: ");
						mes=sn.nextInt();
				     if(mes<=0 || mes>12 ) {
					System.out.println(" Ingrese numero de mes correcto");	
				}
					}
					catch(InputMismatchException e1) {
						System.out.println("Debe ingresar solo numeros");
						mes=0;
						sn.nextLine();
					}
				}while(mes<=0 || mes>12);
				do {
					try {
						System.out.println("Ingrese su anio de Nacimiento: ");
						anio=sn.nextInt();
				     if(anio<=0) {
					System.out.println(" Ingrese un numero de anio correcto");	
				}
					}
					catch(InputMismatchException e1) {
						System.out.println("Debe ingresar solo numeros");
						anio=0;
						sn.nextLine();
					}
				}while(anio<=0);
				fechaNac=new Fecha (dia,mes,anio);
				System.out.println("Ingrese el dia de su Ingreso: ");
				dia=sn.nextInt();
				System.out.println("Ingrese el mes de su Ingreso: ");
				mes=sn.nextInt();
				System.out.println("Ingrese el anio de su Ingreso: ");
				anio=sn.nextInt();
				fechaIngreso=new Fecha(dia,mes,anio);
				//empleado1=new Empleado(nombreEmple, apellidoEmple, genero, imagen, salario, fechaNac, fechaIngreso);
				
				break;
			case 2:
				System.out.println("Usted ha escogido la opci�n 2");
				
				System.out.println(empleado1.calcularEdad());
				break;
				
			case 3:
				System.out.println("Usted ha escogido la opci�n 3");
				System.out.println(empleado1.calcularAntiguedad());
				break;
				
			case 4:
				System.out.println("Usted ha escogido la opci�n 4");
				System.out.println(empleado1.calcularPrestaciones());
				break;
				
			case 5:
				System.out.println("Ustedd ha escogido la opci�n 5");
				empleado1.mostrarInformacion();
				break;
				
			case 6:
				System.out.println("Ustedd ha escogido la opci�n 6");
				System.out.println("Usted ha decidido salir, que tenga un buen dia");
				System.exit(0);
				
			default:
				System.out.println("No ha escogido una opic�n correcta");
				System.out.println("Porfavor vuelva ingresar la opcion correcta");
			
		  }while(opcion!=6);
			
			System.out.println("");
			sn.next();
			}
		}