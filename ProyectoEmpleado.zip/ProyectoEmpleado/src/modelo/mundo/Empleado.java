package modelo.mundo;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Empleado {
	//Atributos
	private String nombreEmpleado;
	private String apellidoEmpleado;
	private int genero; //1 Femenino / 2 Masculino
	private  String imagen;
	private double salario;
	
	private Fecha fechaNacimiento ;
	private Fecha fechaIngreso;
	
	//M�todos Constructores sin par�metros
	public Empleado() {
		nombreEmpleado="";
		apellidoEmpleado="";
		genero=0;
		imagen="";
		salario=0.0;
		
	}
	//M�todo constructor con parametros
	public Empleado(String pNombreEmpleado ,String pApellidoEmpleado, int pGenero,
			String pImagen, double pSalario) {
		nombreEmpleado=pNombreEmpleado;
		apellidoEmpleado= pApellidoEmpleado;
		genero=pGenero;
		imagen=pImagen;
		salario=pSalario;
		
	}
	
	//Metodo analizadores (Permite obtener o modificar la informacion de los atributos)
	//Gettes (obtener) //Setters(Cambiar o modificar)
	public String getNombre() {
		return nombreEmpleado;
	}
	public String getApellidos() {
		return apellidoEmpleado;
	}
	public int getGenero() {
		return genero;
	}
	
	public Fecha getFechaNacimiento() {
		return fechaNacimiento;
	}
	
	public Fecha getFechaIngreso() {
		return fechaIngreso;
	}
	
	public String getImagen () {
		return imagen;
	}
	public double getSalario() {
		return salario;
	}
	
	public Fecha getFechaActual() {
		GregorianCalendar gc = new GregorianCalendar();
		int dia=gc.get(Calendar.DAY_OF_MONTH);
		int mes =gc.get(Calendar.MONTH)+1;
		int anio=gc.get(Calendar.YEAR);
		return fechaIngreso;
		
		
	}
	
	//M�todos Setters
	public void steEmpleado(String pNombreEmpleado,String pApellidoEmpleado, int pGenero,
			String pImagen, double pSalario ) {
		nombreEmpleado=pNombreEmpleado;
		apellidoEmpleado= pApellidoEmpleado;
		genero=pGenero;
		imagen=pImagen;
		salario=pSalario;
	}
	
	public void setSalario(double pSalario) {
		salario = pSalario;
	}
	
	//M�todos funcionales Calcula la antiguedad en a�os
	public int calcularAntiguedad() {
		int antiguedad=0;
		antiguedad=fechaIngreso.darDiferenciaEnMeses(getFechaActual())/12;	
		
		return antiguedad;
		
	}
	
	//M�todo funcional Calcula la edad del empleado en a�os
	public int calcularEdad() {
		int edades;
		edades=fechaIngreso.darDiferenciaEnMeses(getFechaActual())/12;
		return edades;
	}
	
	//M�todo de las prestaciones
		public double calcularPrestaciones() {
			return (calcularAntiguedad () * getSalario () ) / 12;
}
		
	//M�todo que permite visualizar la informaci�n del empleado
		public void mostrarInformacion() {
			System.out.println("La informaci�n del empleado es:");
			System.out.println("Nombre: "+getNombre());
			System.out.println("Apellido: "+ getApellidos());
			System.out.println("G�nero (Masculino 1), (Femenino 0)"+ getGenero());
			System.out.println("Fecha de Nacimiento: "+ getFechaNacimiento());
			System.out.println("Fecha de ingreso a la empresa: "+getFechaIngreso());
			System.out.println("Salario b�sico: "+getSalario());
			System.out.println("Prestaciones: "+calcularPrestaciones());
			System.out.println("Antiguedad: "+calcularAntiguedad()+" a�os.");
		}
		
	    public double calcularPrestaciones1( )throws ArithmeticException{
	        return (calcularAntiguedad()*getSalario())	/12;
	        }
	    
}
