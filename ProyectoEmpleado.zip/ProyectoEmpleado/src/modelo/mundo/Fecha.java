package modelo.mundo;

public class Fecha {
	private int dia;
	private int mes;
	private int anio;
	
	//constructor
	public Fecha (int pDia, int pMes, int pAnio){
		dia=pDia;
		mes= pMes;
		anio=pAnio;
	}
	
	public Fecha() {
		dia=0;
		mes=0;
		anio=0;
	}
	
	//metodo analizadores Getters
	public int getDia() {
		return dia;
	}
	
	public int getMes() {
		return mes;
	}
	
	public int getAnio() {
		return anio;
	}
	
	// M�todo funciones
	// Fecha1 23/04/200    Fecha2 15/agosto/2008
	public int darDiferenciaEnMeses(Fecha pFecha) {
		int numeroMeses =0;
		int difAnios =  pFecha.getAnio() - anio* 12;
		int difMeses = 0;
		if (mes < pFecha.getMes()) {
			difMeses =  pFecha.getMes() - mes;
		}
		int difDias = 0;
		if (mes < pFecha.getMes()) {
			difDias = (pFecha.getDia() - dia )/ 30;
		}
		numeroMeses = difAnios + difMeses + difDias;
		return numeroMeses;
	}
	
	//dd-mm-aa   // dd/mm/aaa     aaa-mm-dd
	public String toString() {
		return dia +"-"+ mes + "-"+anio; 
	}
}
